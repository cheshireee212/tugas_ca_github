// Data buku Harry Potter
const books = [
    {
        number: 1,
        title: "Harry Potter and the Sorcerer's Stone",
        releaseDate: "Jun 26, 1997",
        description: "On his birthday, Harry Potter discovers that he is the son of two well-known wizards, from whom he has inherited magical powers. He must attend a famous school of magic and sorcery, where he establishes a friendship with two young men who will become his companions on his adventure. During his first year at Hogwarts, he discovers that a malevolent and powerful wizard named Voldemort is in search of a philosopher's stone that prolongs the life of its owner.",
        pages: 223,
        cover: "image.png"
    },
    {
        number: 2,
        title: "Harry Potter and the chamber of secrets",
        releaseDate: "Jul 2, 1998",
        description: "Harry Potter and the sophomores investigate a malevolent threat to their Hogwarts classmates, a menacing beast that hides within the castle.",
        pages: 251,
        cover: "image copy.png"
    },
    {
        number: 3,
        title: "Harry Potter and the Prisoner of Azkaban",
        releaseDate: "Jul 8, 1999",
        description: "Harry's third year of studies at Hogwarts is threatened by Sirius Black's escape from Azkaban prison. Apparently, it is a dangerous wizard who was an accomplice of Lord Voldemort and who will try to take revenge on Harry Potter.",
        pages: 317,
        cover: "image copy 2.png"
    },
    {
        number: 4,
        title: "Harry Potter and the Goblet of Fire",
        releaseDate: "Jul 8, 2000",
        description: "Hogwarts prepares for the Triwizard Tournament, in which three schools of wizardry will compete. To everyone's surprise, Harry Potter is chosen to participate in the competition, in which he must fight dragons, enter the water and face his greatest fears.",
        pages: 636,
        cover: "image copy 3.png"
    },
    {
        number: 5,
        title: "Harry Potter and the Order of the Phoenix",
        releaseDate: "Jun 21, 2003",
        description: "In his fifth year at Hogwarts, Harry discovers that many members of the wizarding community do not know the truth about his encounter with Lord Voldemort. Cornelius Fudge, Minister of Magic, appoints Dolores Umbridge as Defense Against the Dark Arts teacher because he believes that Professor Dumbledore plans to take over his job. But his teachings are inadequate, so Harry prepares the students to defend the school against evil.",
        pages: 766,
        cover: "image copy 4.png"
    }
];

// Variabel untuk tracking
let currentIndex = 0;
let isAnimating = false;

// Elements
const bookCover = document.getElementById('bookCover');
const bookTitle = document.getElementById('bookTitle');
const releaseDate = document.getElementById('releaseDate');
const pageCount = document.getElementById('pageCount');
const bookDescription = document.getElementById('bookDescription');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
const paginationDots = document.querySelector('.pagination-dots');

// Function untuk update tampilan
function updateDisplay() {
    const book = books[currentIndex];
    
    // Update konten
    bookCover.src = book.cover;
    bookTitle.textContent = book.title;
    releaseDate.textContent = book.releaseDate;
    pageCount.textContent = book.pages;
    bookDescription.textContent = book.description;
    
    // Update dots
    updatePaginationDots();
}

// Function untuk membuat dots pagination
function createPaginationDots() {
    books.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.classList.add('dot');
        dot.addEventListener('click', () => {
            if (!isAnimating && currentIndex !== index) {
                currentIndex = index;
                updateDisplay();
                animateTransition();
            }
        });
        paginationDots.appendChild(dot);
    });
}

// Function untuk update active dot
function updatePaginationDots() {
    const dots = document.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentIndex);
    });
}

// Function untuk animasi transisi
function animateTransition() {
    if (!isAnimating) {
        isAnimating = true;
        const card = document.querySelector('.book-card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            updateDisplay();
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
            isAnimating = false;
        }, 300);
    }
}

// Event listeners untuk navigasi
prevBtn.addEventListener('click', () => {
    if (!isAnimating) {
        currentIndex = (currentIndex - 1 + books.length) % books.length;
        animateTransition();
    }
});

nextBtn.addEventListener('click', () => {
    if (!isAnimating) {
        currentIndex = (currentIndex + 1) % books.length;
        animateTransition();
    }
});

// Initialize
createPaginationDots();
updateDisplay();

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    if (!isAnimating) {
        if (e.key === 'ArrowLeft') {
            currentIndex = (currentIndex - 1 + books.length) % books.length;
            animateTransition();
        } else if (e.key === 'ArrowRight') {
            currentIndex = (currentIndex + 1) % books.length;
            animateTransition();
        }
    }
});

